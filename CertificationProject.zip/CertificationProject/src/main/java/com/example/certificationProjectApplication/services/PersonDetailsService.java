package com.example.certificationProjectApplication.services;

import com.example.certificationProjectApplication.models.Person;
import com.example.certificationProjectApplication.repositories.PersonRepository;
import com.example.certificationProjectApplication.security.PersonDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PersonDetailsService implements UserDetailsService {
    private final PersonRepository personRepository;

    @Autowired
    public PersonDetailsService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //получение пользователя из таблицы по логину из формы аутентификации
        Optional<Person> person = personRepository.findByLogin(username);
        //в случае, если пользователь не найден
        if (person.isEmpty()) {
            //выбрасываем исключение, что данный пользователь не найден
            //исключение будет поймано Spring Security и на страницу
            //будет выведено сообщение
            throw new UsernameNotFoundException("Пользователь не найден");
        }
        return new PersonDetails(person.get());
    }
}