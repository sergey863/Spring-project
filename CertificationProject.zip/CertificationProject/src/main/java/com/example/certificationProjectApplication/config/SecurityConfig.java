package com.example.certificationProjectApplication.config;

import com.example.certificationProjectApplication.services.PersonDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    private final PersonDetailsService personDetailsService;

    @Autowired
    public SecurityConfig(PersonDetailsService personDetailsService) {
        this.personDetailsService = personDetailsService;
    }

    //конфигурирование Spring Security
    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                //все страницы будут защищены процессом аутентификации
                .authorizeRequests()
                //страница /admin доступна только пользователю с ролью ADMIN
                .antMatchers("/admin").hasRole("ADMIN")
                //страницы доступны всем пользователям
                .antMatchers("/authentication/login", "/authentication/registration", "/error", "/product", "/img/**", "/product/info/{id}", "/product/search").permitAll()
                //остальные страницы доступны пользователям USER и ADMIN
                .anyRequest().hasAnyRole("USER", "ADMIN")
                .and()
                .formLogin().loginPage("/authentication/login")
                //url, на который будут отправляться данные с формы аутентификации
                .loginProcessingUrl("/process_login")
                //url, на который направится пользователь после успешной аутентификации
                .defaultSuccessUrl("/index", true)
                //переход при неверный аутентификации
                .failureUrl("/authentication/login?error")
                .and()
                .logout().logoutUrl("/logout").logoutSuccessUrl("/authentication/login");
    }

    //метод настройки аутентификации
    protected void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        authenticationManagerBuilder.userDetailsService(personDetailsService)
                .passwordEncoder(getPasswordEncoder());
    }
    @Bean
    public PasswordEncoder getPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }
}