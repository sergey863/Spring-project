package com.example.certificationProjectApplication.enumm;

public enum Status {
    Принят, Оформлен, Оплачен, В_ПУТИ, Ожидает, Получен
}
